const Article = require('mongoose').model('Article');
const Edit = require('mongoose').model('Edit');

module.exports = {
	index: (req, res) => {
		Article.find().populate('edits').then((articles) => {
			let recentArticles = articles.sort(function (a, b) {
				return a.creationDate > b.creationDate;
			}).slice(0, 3);
			let featured={isNotEmpty:false};
			console.log(recentArticles);
			if(recentArticles.length>0){
				let featured=recentArticles[0];
				featured.content = featured.edits.sort(function (a, b) {
					return a.dateOfCreation > b.dateOfCreation;
				})[0].content.slice(0, 50);
				featured.isNotEmpty=true;
			}
			
			if(recentArticles.length>0){
				let featured=recentArticles[0];
				featured.content = featured.edits.sort(function (a, b) {
					return a.dateOfCreation > b.dateOfCreation;
				})[0].content.slice(0, 50);
				featured.isNotEmpty=true;
			}
			let dataObj = {
				featured,
				recent:recentArticles.slice(1, 3)
			};

			res.render('home/index', dataObj);
		});


	}
};