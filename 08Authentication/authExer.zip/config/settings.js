module.exports={
	development:{
		port:3000,
		db:'mongodb://localhost:27017/carrental',
		carsPerPage:10
	}
};