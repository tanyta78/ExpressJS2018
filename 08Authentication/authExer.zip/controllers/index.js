const home = require('./home-controller');
const user = require('./user-controller');
const admin = require('./admin-controller');
const car = require('./car-controller');

module.exports = {
	home,
	user,
	admin,
	car
};